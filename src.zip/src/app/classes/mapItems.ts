export class mapItemClass{
    constructor(
        public mapLat:number,
        public mapLng:number,
        public mapZoom,
        public mapType:string,
        public mapRadius:number,
        public mapMenu:string,
        public mapTravelMode:string 
         ){}
    }